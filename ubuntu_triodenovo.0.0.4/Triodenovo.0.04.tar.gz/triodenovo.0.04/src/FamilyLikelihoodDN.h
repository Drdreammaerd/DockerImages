#ifndef __FAMILYLIKELIHOODDN_H__
#define __FAMILYLIKELIHOODDN_H__

#include <string>
#include "FamilyLikelihoodES.h"
#include "MutationModel.h"
#include "CmdLinePar.h"

#include <cassert>
#include <string>
#include <set>
#include <map>
#include <vector>
#include <algorithm>
#include <iostream>
#include "Argument.h"
#include "IO.h"
#include "tabix.h"
#include "PeopleSet.h"
#include "RangeList.h"
#include "VCFUtil.h"

using namespace std;

class TrioConfigInfo
{
 public:
	int p1;
	int p2;
	int child;
	double lk;
	double lk_joint_max;
	double logbf;
	double posterior;
	double qual;
 public:
  TrioConfigInfo()
  {
   p1 = p2 = child = 0;
   lk = lk_joint_max = -1.0;
   logbf = posterior = qual = -1.0;
  }
};

class FamilyLikelihoodDN
{
 public:
  FamilyLikelihoodES * fam;
  Pedigree *ped;
  CmdLinePar par;

  AlleleMutationModel aM;
  GenotypeMutationModel gM;

  std::string refStr;
  std::string altStr;
  VCFInputFile *vin;
  VCFRecord *r;
  VCFPeople *people;

  std::vector<std::string> pids;
  std::vector<std::string> includedPIDs;
  std::map<std::string, std::pair<int, int> > pid2traverse;
  std::map<std::string, int> included;
  std::string vcfInFile;
  int GL_idx;
  int PL_idx;
  int ref;
  int alt;
  int allele1;
  int allele2;
  int alleles[2];
  int genotype_index[3];
  std::vector<std::string> genotype10_labels;
  std::vector<std::string> genotype10_labels_X_Male;
  int position;
  int nFields;
  double QUAL;
  int GT_index, GQ_index, DP_index;
  std::vector<std::vector<int> > sexes; 
  int maleFounders, femaleFounders;
  double PL2LK_table[1024];
  bool pid_match;
  int withdata_cnt;
  int nSamplesWithData;

  bool isBiallelic;
  bool isIndel;
  bool isChrX;
  bool isChrY;
  bool isMT;

  double theta;
  double theta_indel;
  double prior;
  double prior_indel;
  double parentPrior[9];

  std::vector<TrioConfigInfo> trio_info;

 public:
  FamilyLikelihoodDN();
  ~FamilyLikelihoodDN();

  void InitFamilyLikelihoodES();
  void FillPenetrance();
  void SetPedigree(Pedigree* p);
  //void SetVinPtr(VCFInputFile *v) { vin = v; }
  void SetVCFInput(std::string vcfInput);
  void SetPar(CmdLinePar& cmdpar) { par = cmdpar; }
  void SetDenovoMutationModel();

  void MapPID2Traverse();
  double PL2LK(int);
  int Allele2Int(std::string&);
  void FillZeroPenetrance(int fam_idx, int person_idx, int geno_idx);
  void GetSexes();
  void PrintPenetranceMatrix();
  void PrintLogLKMatrix();

  //void SetPolyPrior_chrY();
  //void SetPolyPrior_chrX();
  //void SetPolyPrior_MT();
  //void SetPolyPrior(int famIdx);
  //void SetPolyPrior_indel(int famIdx);
  double GetPrior_ts(double tstv_ratio);
  double GetPrior_tv(double tstv_ratio);
  double GetPolyPrior(int famIdx);
  double GetPolyPrior_indel(int famIdx);
  bool isTs(int a1, int a2);
  bool isTv(int a1, int a2);
  void denovo_calling();
  double denovo_calling_single_trio(int famIdx, TrioConfigInfo&);
  int GenotypeIndex(int base1, int base2);
  double CalcLikelihoodM00(int famIdx);
  double CalcLikelihoodM0(int famIdx);
  double CalcLikelihoodM1(int famIdx);
  double CalcLikelihoodM1(int famIdx, TrioConfigInfo&);
  double CalcLikelihoodM11(int famIdx);
  void OutputVCF(FILE*);
};

#endif
