#include <stdlib.h>
#include <iostream>
#include "Parameters.h"
#include "CmdLinePar.h"
#include "MutationModel.h"
#include <map>
#include "FamilyLikelihoodES.h"
#include "FamilyLikelihoodDN.h"

int main(int argc, char * argv[])
{
  double posterior = 0.5;
  int minTotalDepth = 0;
  int maxTotalDepth = 0;
  int minDepthInTrio = 5;
  int maxDepthInTrio = 0;
  String pedFile;
  String vcfOutFile = "";
  String vcfInFile ="";
  double theta = 0.001;
  double theta_indel = 0.0001;
  double tstv_ratio = 2.0;
  double min_lbf = 5;
  double mutation_rate = 1e-7;
  bool mixed_vcf_records;

  String chrX_label("X");
  String chrY_label("Y");
  String MT_label("MT");

  const char *buildString = "\n   *** This build (v.0.04) was compiled on " __DATE__  ", " __TIME__ " ***\n";
  printf("%s", buildString);

  ParameterList pl;

  BEGIN_LONG_PARAMETERS(longParameters)
    LONG_PARAMETER_GROUP("Input files")
    LONG_STRINGPARAMETER("ped", &pedFile)
    LONG_STRINGPARAMETER("in_vcf", &vcfInFile)
    LONG_PARAMETER_GROUP("Output files")
    LONG_STRINGPARAMETER("out_vcf", &vcfOutFile)
    LONG_PARAMETER_GROUP("Denovo mutation rate")
    LONG_DOUBLEPARAMETER("mu", &mutation_rate)
    LONG_PARAMETER_GROUP("Scaled mutation rate")
    LONG_DOUBLEPARAMETER("theta", &theta)
    LONG_DOUBLEPARAMETER("indel_theta", &theta_indel)
    LONG_PARAMETER_GROUP("Prior of de novo ts/tv ratio")
    LONG_DOUBLEPARAMETER("denovo_tstv", &tstv_ratio)
    LONG_PARAMETER_GROUP("Non-autosome labels")
      LONG_STRINGPARAMETER("chrX", &chrX_label)
    //  LONG_STRINGPARAMETER("chrY", &chrY_label)
    //  LONG_STRINGPARAMETER("MT", &MT_label)
    LONG_PARAMETER_GROUP("Filters")
      LONG_DOUBLEPARAMETER("minDQ", &min_lbf)
    LONG_INTPARAMETER("minTotalDepth", &minTotalDepth)
    LONG_INTPARAMETER("maxTotalDepth", &maxTotalDepth)
    LONG_INTPARAMETER("minDepth", &minDepthInTrio)
    LONG_INTPARAMETER("maxDepth", &maxDepthInTrio)
    LONG_PARAMETER("mixed_vcf_records", &mixed_vcf_records)

    END_LONG_PARAMETERS();

  pl.Add(new LongParameters("", longParameters));
  pl.Read(argc, argv);

  pl.Status();

  if(vcfInFile==vcfOutFile) error("Input and output VCF files are the same!\n");

  if(pedFile.Length()==0)
    error("pedFile not provided for trios: use --ped input.ped\n");
  if(vcfInFile.Length()==0)
    error("Input VCF file not provided: use --in_vcf input.vcf\n");
  if(vcfOutFile.Length()==0)
    error("Output VCF file not provided: use --out_vcf out.vcf\n");

  std::string cmd;
  for(int a=0; a<argc; a++)
  {
   cmd += std::string(argv[a]);
   cmd += " ";
  }

  CmdLinePar par;
  par.cmd = cmd;
  par.mutation_rate = mutation_rate;
  par.theta = theta;
  par.theta_indel = theta_indel;
  par.minTotalDepth = minTotalDepth;
  par.maxTotalDepth = maxTotalDepth;
  par.minDepthInTrio = minDepthInTrio;
  par.maxDepthInTrio = maxDepthInTrio;
  par.tstv_ratio = tstv_ratio;
  par.min_lbf = min_lbf;
  par.chrX_label = chrX_label;
  par.chrY_label = chrY_label;
  par.MT_label = MT_label;
  par.vcfInFile = vcfInFile;
  par.vcfOutFile = vcfOutFile;
  par.mixed_vcf_records = mixed_vcf_records;

  Pedigree ped;
  IFILE pedFH = ifopen(pedFile, "r");
  FILE *vcfFH = fopen(vcfOutFile, "w");

  if(pedFH==NULL)
    error("pedFile open for input failed!\n");
  if(vcfFH==NULL)
    error("vcfOutFile can not be opened for output!\n");

  ped.Load(pedFH);

  if(pedFH != NULL) ifclose(pedFH);

  FamilyLikelihoodDN dn;

  dn.SetPar(par);
  dn.SetPedigree(&ped);
  dn.SetVCFInput(std::string(vcfInFile.c_str()));

  dn.denovo_calling();
}
