#ifndef __MAPFUNCTION_H__
#define __MAPFUNCTION_H__

double DistanceToRecombination(double distance);
double RecombinationToDistance(double recombination);

#endif
