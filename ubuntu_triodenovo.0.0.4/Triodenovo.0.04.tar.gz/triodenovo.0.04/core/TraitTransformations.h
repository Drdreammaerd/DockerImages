#ifndef __TRAIT_TRANSFORMS__
#define __TRAIT_TRANSFORMS__

#include "Pedigree.h"

void InverseNormalTransform(Pedigree & ped);
void InverseNormalTransform(Pedigree & ped, int trait);

#endif

 

