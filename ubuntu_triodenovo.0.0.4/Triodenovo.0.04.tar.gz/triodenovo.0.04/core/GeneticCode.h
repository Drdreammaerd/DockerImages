#ifndef __GENETICCODE_H__
#define __GENETICCODE_H__

extern const char * codons[64];
extern const char * codons2aminoAcids[64];
extern const char * codons2letters[64];

extern const char * aminoAcids[21];
extern const char * aminoAcidLetters[21];

#endif
