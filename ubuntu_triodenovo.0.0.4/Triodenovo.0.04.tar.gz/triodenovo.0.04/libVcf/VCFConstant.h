#ifndef _VCFCONSTANT_H_
#define _VCFCONSTANT_H_


#define MISSING_GENOTYPE -9


#endif /* _VCFCONSTANT_H_ */
