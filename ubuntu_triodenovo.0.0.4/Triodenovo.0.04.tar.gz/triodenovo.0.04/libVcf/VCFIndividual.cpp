#include "VCFIndividual.h"

VCFValue VCFIndividual::defaultVCFValue;

